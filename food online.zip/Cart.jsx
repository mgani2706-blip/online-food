import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function Cart() {
  const { items, restaurantName, subtotal, updateQuantity, removeFromCart, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const deliveryFee = 30;
  const total = subtotal + deliveryFee;

  const handleCheckout = () => {
    if (!user) { navigate('/login?redirect=/checkout'); return; }
    navigate('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag size={40} className="text-orange-300" />
        </div>
        <h2 className="font-display text-2xl font-bold text-stone-900 mb-2">Your cart is empty</h2>
        <p className="text-stone-500 mb-6">Add items from a restaurant to get started</p>
        <Link to="/restaurants" className="bg-orange-500 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-orange-600 inline-block">
          Browse Restaurants
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-stone-900">Your Cart</h1>
          <p className="text-stone-500 text-sm mt-0.5">from {restaurantName}</p>
        </div>
        <button onClick={clearCart} className="text-red-400 hover:text-red-600 text-sm font-medium flex items-center gap-1">
          <Trash2 size={14} /> Clear Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-3">
          {items.map(item => (
            <div key={item._id} className="bg-white rounded-2xl border border-stone-100 p-4 flex items-center gap-4">
              <img src={item.image} alt={item.name} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-stone-900 truncate">{item.name}</h3>
                <p className="text-orange-500 font-bold mt-0.5">₹{item.price}</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-orange-50 rounded-xl px-2 py-1">
                  <button onClick={() => updateQuantity(item._id, item.quantity - 1)} className="text-orange-500 hover:text-orange-700">
                    <Minus size={14} />
                  </button>
                  <span className="font-bold text-stone-900 w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item._id, item.quantity + 1)} className="text-orange-500 hover:text-orange-700">
                    <Plus size={14} />
                  </button>
                </div>
                <p className="font-bold text-stone-900 w-16 text-right">₹{item.price * item.quantity}</p>
                <button onClick={() => removeFromCart(item._id)} className="text-stone-300 hover:text-red-500 transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl border border-stone-100 p-5 sticky top-20">
            <h2 className="font-semibold text-stone-900 mb-4">Order Summary</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal ({items.reduce((s, i) => s + i.quantity, 0)} items)</span>
                <span>₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Delivery Fee</span>
                <span>₹{deliveryFee}</span>
              </div>
              <div className="border-t border-stone-100 pt-3 flex justify-between font-bold text-stone-900 text-base">
                <span>Total</span>
                <span>₹{total}</span>
              </div>
            </div>
            <button onClick={handleCheckout}
              className="w-full mt-5 bg-orange-500 text-white py-3.5 rounded-2xl font-semibold hover:bg-orange-600 transition-colors flex items-center justify-center gap-2">
              Proceed to Checkout <ArrowRight size={18} />
            </button>
            <Link to="/restaurants" className="block text-center text-stone-400 hover:text-stone-600 text-sm mt-3 font-medium">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
