import React, { createContext, useContext, useState, useEffect } from 'react';
import toast from 'react-hot-toast';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [restaurantId, setRestaurantId] = useState(null);
  const [restaurantName, setRestaurantName] = useState('');

  useEffect(() => {
    const stored = localStorage.getItem('foodash_cart');
    if (stored) {
      const { items, restaurantId, restaurantName } = JSON.parse(stored);
      setItems(items || []);
      setRestaurantId(restaurantId || null);
      setRestaurantName(restaurantName || '');
    }
  }, []);

  const persist = (newItems, rId, rName) => {
    localStorage.setItem('foodash_cart', JSON.stringify({ items: newItems, restaurantId: rId, restaurantName: rName }));
  };

  const addToCart = (food, restaurant) => {
    // If different restaurant, ask user
    if (restaurantId && restaurantId !== restaurant._id) {
      if (!window.confirm(`Your cart has items from "${restaurantName}". Clear cart and add from "${restaurant.name}"?`)) return;
      setItems([]);
      setRestaurantId(null);
      setRestaurantName('');
    }

    setItems(prev => {
      const existing = prev.find(i => i._id === food._id);
      let updated;
      if (existing) {
        updated = prev.map(i => i._id === food._id ? { ...i, quantity: i.quantity + 1 } : i);
      } else {
        updated = [...prev, { ...food, quantity: 1 }];
      }
      persist(updated, restaurant._id, restaurant.name);
      return updated;
    });

    setRestaurantId(restaurant._id);
    setRestaurantName(restaurant.name);
    toast.success(`${food.name} added to cart!`);
  };

  const removeFromCart = (foodId) => {
    setItems(prev => {
      const updated = prev.filter(i => i._id !== foodId);
      if (updated.length === 0) {
        setRestaurantId(null);
        setRestaurantName('');
        persist([], null, '');
      } else {
        persist(updated, restaurantId, restaurantName);
      }
      return updated;
    });
  };

  const updateQuantity = (foodId, quantity) => {
    if (quantity <= 0) { removeFromCart(foodId); return; }
    setItems(prev => {
      const updated = prev.map(i => i._id === foodId ? { ...i, quantity } : i);
      persist(updated, restaurantId, restaurantName);
      return updated;
    });
  };

  const clearCart = () => {
    setItems([]);
    setRestaurantId(null);
    setRestaurantName('');
    localStorage.removeItem('foodash_cart');
  };

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider value={{
      items, restaurantId, restaurantName,
      addToCart, removeFromCart, updateQuantity, clearCart,
      subtotal, itemCount
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
