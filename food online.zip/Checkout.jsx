import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, CreditCard, Banknote, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function Checkout() {
  const { items, restaurantId, subtotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const deliveryFee = 30;
  const total = subtotal + deliveryFee;

  const [address, setAddress] = useState({
    street: user?.address?.street || '',
    city: user?.address?.city || '',
    state: user?.address?.state || '',
    pincode: user?.address?.pincode || ''
  });
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePlaceOrder = async () => {
    if (!address.street || !address.city) {
      toast.error('Please fill in delivery address');
      return;
    }
    if (!items.length) { toast.error('Cart is empty'); return; }

    setLoading(true);
    try {
      const orderPayload = {
        restaurantId,
        items: items.map(i => ({ foodId: i._id, quantity: i.quantity })),
        deliveryAddress: address,
        paymentMethod,
        notes
      };

      const { data } = await api.post('/orders', orderPayload);

      if (paymentMethod === 'razorpay') {
        // Razorpay integration
        const rzpRes = await api.post('/payment/razorpay/create', { amount: total, orderId: data.order._id });
        const options = {
          key: process.env.REACT_APP_RAZORPAY_KEY_ID,
          amount: rzpRes.data.amount,
          currency: 'INR',
          name: 'FooDash',
          description: 'Food Delivery',
          order_id: rzpRes.data.rzpOrderId,
          handler: async (response) => {
            await api.post('/payment/razorpay/verify', {
              ...response,
              orderId: data.order._id
            });
            clearCart();
            navigate(`/order-success/${data.order._id}`);
          },
          prefill: { name: user.name, email: user.email, contact: user.phone },
          theme: { color: '#f97316' }
        };
        const rzp = new window.Razorpay(options);
        rzp.open();
        setLoading(false);
        return;
      }

      clearCart();
      toast.success('Order placed successfully! 🎉');
      navigate(`/order-success/${data.order._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
    }
    setLoading(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="font-display text-2xl font-bold text-stone-900 mb-6">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Delivery Address */}
          <div className="bg-white rounded-2xl border border-stone-100 p-6">
            <h2 className="font-semibold text-stone-900 mb-4 flex items-center gap-2"><MapPin size={18} className="text-orange-500" />Delivery Address</h2>
            <div className="grid grid-cols-1 gap-3">
              <input value={address.street} onChange={e => setAddress({...address, street: e.target.value})}
                placeholder="Street address *"
                className="w-full px-4 py-3 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              <div className="grid grid-cols-2 gap-3">
                <input value={address.city} onChange={e => setAddress({...address, city: e.target.value})}
                  placeholder="City *"
                  className="px-4 py-3 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
                <input value={address.state} onChange={e => setAddress({...address, state: e.target.value})}
                  placeholder="State"
                  className="px-4 py-3 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              </div>
              <input value={address.pincode} onChange={e => setAddress({...address, pincode: e.target.value})}
                placeholder="Pincode"
                className="w-full px-4 py-3 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-2xl border border-stone-100 p-6">
            <h2 className="font-semibold text-stone-900 mb-4 flex items-center gap-2"><CreditCard size={18} className="text-orange-500" />Payment Method</h2>
            <div className="space-y-3">
              {[
                { value: 'cod', label: 'Cash on Delivery', icon: <Banknote size={20} className="text-green-500" />, desc: 'Pay when you receive your order' },
                { value: 'razorpay', label: 'Razorpay', icon: <CreditCard size={20} className="text-blue-500" />, desc: 'UPI, Cards, Net Banking & more' },
              ].map(opt => (
                <label key={opt.value} className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                  paymentMethod === opt.value ? 'border-orange-400 bg-orange-50' : 'border-stone-200 hover:border-orange-200'
                }`}>
                  <input type="radio" value={opt.value} checked={paymentMethod === opt.value} onChange={() => setPaymentMethod(opt.value)} className="hidden" />
                  {opt.icon}
                  <div className="flex-1">
                    <p className="font-medium text-stone-900 text-sm">{opt.label}</p>
                    <p className="text-xs text-stone-500">{opt.desc}</p>
                  </div>
                  {paymentMethod === opt.value && <CheckCircle size={18} className="text-orange-500" />}
                </label>
              ))}
            </div>
          </div>

          {/* Order notes */}
          <div className="bg-white rounded-2xl border border-stone-100 p-6">
            <h2 className="font-semibold text-stone-900 mb-3">Special Instructions</h2>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3}
              placeholder="Any special instructions for your order or delivery..."
              className="w-full px-4 py-3 rounded-xl border border-stone-200 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-orange-300" />
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl border border-stone-100 p-5 sticky top-20">
            <h2 className="font-semibold text-stone-900 mb-4">Order Summary</h2>
            <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
              {items.map(item => (
                <div key={item._id} className="flex justify-between text-sm">
                  <span className="text-stone-600 truncate flex-1 mr-2">{item.name} × {item.quantity}</span>
                  <span className="font-medium text-stone-900">₹{item.price * item.quantity}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-stone-100 pt-3 space-y-2 text-sm">
              <div className="flex justify-between text-stone-600"><span>Subtotal</span><span>₹{subtotal}</span></div>
              <div className="flex justify-between text-stone-600"><span>Delivery</span><span>₹{deliveryFee}</span></div>
              <div className="flex justify-between font-bold text-stone-900 text-base pt-1 border-t border-stone-100">
                <span>Total</span><span>₹{total}</span>
              </div>
            </div>
            <button onClick={handlePlaceOrder} disabled={loading}
              className="w-full mt-4 bg-orange-500 text-white py-3.5 rounded-2xl font-semibold hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              {loading ? 'Placing Order...' : `Place Order • ₹${total}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
