import React from 'react';
import { Plus, Minus, Star, Flame } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function FoodItemCard({ food, restaurant }) {
  const { items, addToCart, updateQuantity } = useCart();
  const cartItem = items.find(i => i._id === food._id);
  const qty = cartItem?.quantity || 0;

  return (
    <div className="bg-white rounded-2xl border border-stone-100 overflow-hidden flex gap-4 p-4 card-hover">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className={food.isVeg ? 'veg-indicator' : 'nonveg-indicator'} title={food.isVeg ? 'Veg' : 'Non-Veg'} />
          {food.isBestSeller && (
            <span className="text-xs bg-amber-100 text-amber-700 font-semibold px-2 py-0.5 rounded-full flex items-center gap-1">
              <Flame size={10} /> Bestseller
            </span>
          )}
        </div>
        <h3 className="font-semibold text-stone-900 mb-0.5 text-base leading-tight">{food.name}</h3>
        <div className="flex items-center gap-1 text-amber-500 text-xs mb-1">
          <Star size={11} fill="currentColor" />
          <span className="font-medium">{food.rating}</span>
        </div>
        <p className="text-xs text-stone-500 mb-3 line-clamp-2">{food.description}</p>
        <p className="font-bold text-stone-900 text-lg">₹{food.price}</p>
      </div>

      <div className="flex flex-col items-center justify-between w-24 flex-shrink-0">
        <div className="w-24 h-24 rounded-xl overflow-hidden bg-stone-100">
          <img src={food.image} alt={food.name} className="w-full h-full object-cover" />
        </div>
        <div className="mt-3 w-full">
          {qty === 0 ? (
            <button onClick={() => addToCart(food, restaurant)}
              className="w-full bg-orange-50 border border-orange-400 text-orange-600 text-sm font-bold py-1.5 rounded-xl hover:bg-orange-500 hover:text-white transition-colors flex items-center justify-center gap-1">
              <Plus size={14} /> ADD
            </button>
          ) : (
            <div className="flex items-center justify-between bg-orange-500 rounded-xl px-2 py-1">
              <button onClick={() => updateQuantity(food._id, qty - 1)} className="text-white hover:text-orange-200 transition-colors">
                <Minus size={14} />
              </button>
              <span className="text-white font-bold text-sm">{qty}</span>
              <button onClick={() => addToCart(food, restaurant)} className="text-white hover:text-orange-200 transition-colors">
                <Plus size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
