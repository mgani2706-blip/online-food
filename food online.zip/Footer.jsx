import React from 'react';
import { Link } from 'react-router-dom';
import { ChefHat, Instagram, Twitter, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-stone-900 text-stone-400 mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center">
                <ChefHat size={20} className="text-white" />
              </div>
              <span className="font-display text-xl font-bold text-white">Foo<span className="text-orange-400">Dash</span></span>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">Your favorite food, delivered fast. Fresh meals from top restaurants right to your door.</p>
            <div className="flex gap-4 mt-4">
              <a href="#" className="hover:text-orange-400 transition-colors"><Instagram size={18} /></a>
              <a href="#" className="hover:text-orange-400 transition-colors"><Twitter size={18} /></a>
              <a href="#" className="hover:text-orange-400 transition-colors"><Facebook size={18} /></a>
            </div>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/restaurants" className="hover:text-orange-400 transition-colors">Restaurants</Link></li>
              <li><Link to="/orders" className="hover:text-orange-400 transition-colors">My Orders</Link></li>
              <li><Link to="/profile" className="hover:text-orange-400 transition-colors">Profile</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-orange-400 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-stone-800 mt-8 pt-6 text-center text-xs">
          © {new Date().getFullYear()} FooDash. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
