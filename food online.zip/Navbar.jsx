import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, Menu, X, ChefHat, LayoutDashboard, LogOut, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/'); setProfileOpen(false); };

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-stone-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center group-hover:bg-orange-600 transition-colors">
            <ChefHat size={20} className="text-white" />
          </div>
          <span className="font-display text-xl font-bold text-stone-900">Foo<span className="text-orange-500">Dash</span></span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6">
          <Link to="/restaurants" className="text-stone-600 hover:text-orange-500 font-medium text-sm">Restaurants</Link>
          {isAdmin && <Link to="/admin" className="text-stone-600 hover:text-orange-500 font-medium text-sm">Admin</Link>}

          {/* Cart */}
          <Link to="/cart" className="relative p-2 rounded-xl hover:bg-orange-50 transition-colors">
            <ShoppingCart size={22} className="text-stone-700" />
            {itemCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-orange-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                {itemCount > 9 ? '9+' : itemCount}
              </span>
            )}
          </Link>

          {/* Profile dropdown */}
          {user ? (
            <div className="relative">
              <button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center gap-2 bg-stone-100 hover:bg-stone-200 rounded-full px-3 py-1.5 transition-colors">
                <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">{user.name[0].toUpperCase()}</span>
                </div>
                <span className="text-sm font-medium text-stone-700">{user.name.split(' ')[0]}</span>
              </button>
              {profileOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-stone-100 py-2 z-50">
                  <Link to="/profile" onClick={() => setProfileOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-stone-700 hover:bg-orange-50 hover:text-orange-600">
                    <User size={16} /> Profile
                  </Link>
                  <Link to="/orders" onClick={() => setProfileOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-stone-700 hover:bg-orange-50 hover:text-orange-600">
                    <Package size={16} /> My Orders
                  </Link>
                  {isAdmin && (
                    <Link to="/admin" onClick={() => setProfileOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-stone-700 hover:bg-orange-50 hover:text-orange-600">
                      <LayoutDashboard size={16} /> Dashboard
                    </Link>
                  )}
                  <hr className="my-1 border-stone-100" />
                  <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50">
                    <LogOut size={16} /> Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link to="/login" className="text-sm font-medium text-stone-700 hover:text-orange-500">Login</Link>
              <Link to="/register" className="bg-orange-500 text-white text-sm font-medium px-4 py-2 rounded-xl hover:bg-orange-600">Sign Up</Link>
            </div>
          )}
        </div>

        {/* Mobile: cart + menu */}
        <div className="md:hidden flex items-center gap-3">
          <Link to="/cart" className="relative p-2">
            <ShoppingCart size={22} className="text-stone-700" />
            {itemCount > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 bg-orange-500 text-white text-xs rounded-full flex items-center justify-center font-bold">{itemCount}</span>}
          </Link>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-stone-100 px-4 py-4 space-y-3">
          <Link to="/restaurants" onClick={() => setMobileOpen(false)} className="block text-stone-700 font-medium py-2">Restaurants</Link>
          {user ? (
            <>
              <Link to="/orders" onClick={() => setMobileOpen(false)} className="block text-stone-700 font-medium py-2">My Orders</Link>
              <Link to="/profile" onClick={() => setMobileOpen(false)} className="block text-stone-700 font-medium py-2">Profile</Link>
              {isAdmin && <Link to="/admin" onClick={() => setMobileOpen(false)} className="block text-stone-700 font-medium py-2">Admin Dashboard</Link>}
              <button onClick={handleLogout} className="block w-full text-left text-red-500 font-medium py-2">Logout</button>
            </>
          ) : (
            <div className="flex gap-3">
              <Link to="/login" onClick={() => setMobileOpen(false)} className="flex-1 text-center border border-stone-300 rounded-xl py-2 text-sm font-medium">Login</Link>
              <Link to="/register" onClick={() => setMobileOpen(false)} className="flex-1 text-center bg-orange-500 text-white rounded-xl py-2 text-sm font-medium">Sign Up</Link>
            </div>
          )}
        </div>
      )}

      {profileOpen && <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />}
    </nav>
  );
}
