import React, { useState } from 'react';
import { User, Save } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || '', phone: user?.phone || '',
    street: user?.address?.street || '', city: user?.address?.city || '',
    state: user?.address?.state || '', pincode: user?.address?.pincode || ''
  });
  const [loading, setLoading] = useState(false);
  const update = f => e => setForm({...form, [f]: e.target.value});

  const handleSave = async () => {
    setLoading(true);
    try {
      const { data } = await api.put('/auth/profile', {
        name: form.name, phone: form.phone,
        address: { street: form.street, city: form.city, state: form.state, pincode: form.pincode }
      });
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error('Update failed');
    }
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <h1 className="font-display text-2xl font-bold text-stone-900 mb-6">My Profile</h1>
      <div className="bg-white rounded-2xl border border-stone-100 p-6 mb-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center">
            <span className="text-2xl font-bold text-orange-500">{user?.name[0]?.toUpperCase()}</span>
          </div>
          <div>
            <h2 className="font-semibold text-stone-900 text-lg">{user?.name}</h2>
            <p className="text-stone-500 text-sm">{user?.email}</p>
            <span className="text-xs bg-orange-100 text-orange-600 font-semibold px-2 py-0.5 rounded-full">{user?.role}</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1">Full Name</label>
              <input value={form.name} onChange={update('name')} className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            </div>
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1">Phone</label>
              <input value={form.phone} onChange={update('phone')} className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Street Address</label>
            <input value={form.street} onChange={update('street')} className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <input value={form.city} onChange={update('city')} placeholder="City" className="px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            <input value={form.state} onChange={update('state')} placeholder="State" className="px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            <input value={form.pincode} onChange={update('pincode')} placeholder="Pincode" className="px-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
          </div>
        </div>

        <button onClick={handleSave} disabled={loading}
          className="mt-5 bg-orange-500 text-white px-6 py-2.5 rounded-xl font-semibold hover:bg-orange-600 transition-colors flex items-center gap-2 disabled:opacity-60">
          <Save size={16} /> {loading ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  );
}
