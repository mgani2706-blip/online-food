import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChefHat } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    setLoading(true);
    try {
      await register(form.name, form.email, form.password, form.phone);
      toast.success('Account created!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    }
    setLoading(false);
  };

  const update = field => e => setForm({...form, [field]: e.target.value});

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center">
              <ChefHat size={22} className="text-white" />
            </div>
            <span className="font-display text-2xl font-bold text-stone-900">Foo<span className="text-orange-500">Dash</span></span>
          </Link>
          <h1 className="font-display text-2xl font-bold text-stone-900">Create account</h1>
          <p className="text-stone-500 text-sm mt-1">Join FooDash today</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl shadow-orange-100 p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { label: 'Full Name', field: 'name', type: 'text', placeholder: 'John Doe', required: true },
              { label: 'Email', field: 'email', type: 'email', placeholder: 'you@example.com', required: true },
              { label: 'Phone', field: 'phone', type: 'tel', placeholder: '9876543210', required: false },
              { label: 'Password', field: 'password', type: 'password', placeholder: 'Min 6 characters', required: true },
            ].map(field => (
              <div key={field.field}>
                <label className="block text-sm font-medium text-stone-700 mb-1.5">{field.label}</label>
                <input type={field.type} value={form[field.field]} onChange={update(field.field)}
                  placeholder={field.placeholder} required={field.required}
                  className="w-full px-4 py-3 rounded-xl border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              </div>
            ))}
            <button type="submit" disabled={loading}
              className="w-full bg-orange-500 text-white py-3.5 rounded-xl font-semibold hover:bg-orange-600 transition-colors disabled:opacity-60">
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>
          <p className="text-center text-sm text-stone-500 mt-5">
            Already have an account?{' '}
            <Link to="/login" className="text-orange-500 font-semibold hover:text-orange-600">Sign In</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
