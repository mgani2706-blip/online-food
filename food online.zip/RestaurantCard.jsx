import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Clock, Bike } from 'lucide-react';

export default function RestaurantCard({ restaurant }) {
  return (
    <Link to={`/restaurant/${restaurant._id}`} className="group block bg-white rounded-2xl overflow-hidden border border-stone-100 card-hover">
      <div className="relative h-44 overflow-hidden">
        <img src={restaurant.image} alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        {!restaurant.isOpen && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="bg-white text-stone-700 font-semibold text-sm px-4 py-1 rounded-full">Closed</span>
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          {restaurant.tags?.slice(0, 1).map(tag => (
            <span key={tag} className="bg-orange-500 text-white text-xs font-semibold px-2 py-0.5 rounded-full">{tag}</span>
          ))}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-stone-900 text-base mb-0.5 truncate">{restaurant.name}</h3>
        <p className="text-xs text-stone-500 mb-3 truncate">{restaurant.cuisine?.join(', ')}</p>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1 text-amber-500 font-semibold">
            <Star size={14} fill="currentColor" />
            <span>{restaurant.rating}</span>
            <span className="text-stone-400 font-normal">({restaurant.totalReviews})</span>
          </div>
          <div className="flex items-center gap-3 text-stone-500">
            <span className="flex items-center gap-1"><Clock size={13} />{restaurant.deliveryTime}</span>
            <span className="flex items-center gap-1"><Bike size={13} />₹{restaurant.deliveryFee}</span>
          </div>
        </div>
        <div className="mt-2 text-xs text-stone-400">Min order: ₹{restaurant.minOrder}</div>
      </div>
    </Link>
  );
}
