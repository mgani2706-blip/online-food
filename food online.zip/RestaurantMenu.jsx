import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Clock, Bike, MapPin, ChevronRight, ShoppingCart } from 'lucide-react';
import api from '../utils/api';
import FoodItemCard from '../components/FoodItemCard';
import { useCart } from '../context/CartContext';

export default function RestaurantMenu() {
  const { id } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const [menu, setMenu] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const { itemCount, subtotal } = useCart();

  useEffect(() => {
    api.get(`/restaurants/${id}`).then(({ data }) => {
      setRestaurant(data.restaurant);
      setMenu(data.menu);
      const firstCat = Object.keys(data.menu)[0];
      if (firstCat) setActiveCategory(firstCat);
    }).catch(() => {}).finally(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <div className="h-56 skeleton rounded-3xl mb-6" />
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-1 space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-10 skeleton rounded-xl" />)}</div>
        <div className="col-span-2 space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-32 skeleton rounded-2xl" />)}</div>
      </div>
    </div>
  );

  if (!restaurant) return <div className="text-center py-20"><p className="text-stone-500">Restaurant not found</p></div>;

  const categories = Object.keys(menu);
  const filteredMenu = {};
  categories.forEach(cat => {
    const items = vegOnly ? menu[cat].filter(i => i.isVeg) : menu[cat];
    if (items.length) filteredMenu[cat] = items;
  });

  return (
    <div>
      {/* Hero Banner */}
      <div className="relative h-52 md:h-64 overflow-hidden">
        <img src={restaurant.image} alt={restaurant.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="max-w-7xl mx-auto">
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-1">{restaurant.name}</h1>
            <p className="text-white/80 text-sm">{restaurant.cuisine?.join(' · ')}</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Info bar */}
        <div className="bg-white rounded-2xl border border-stone-100 p-4 mb-6 flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-1 text-amber-500 font-semibold">
            <Star size={16} fill="currentColor" />
            <span>{restaurant.rating}</span>
            <span className="text-stone-400 font-normal text-sm">({restaurant.totalReviews} reviews)</span>
          </div>
          <div className="flex items-center gap-1 text-stone-500 text-sm"><Clock size={15} />{restaurant.deliveryTime}</div>
          <div className="flex items-center gap-1 text-stone-500 text-sm"><Bike size={15} />₹{restaurant.deliveryFee} delivery</div>
          <div className="flex items-center gap-1 text-stone-500 text-sm"><MapPin size={15} />{restaurant.address?.city}</div>
          <div className="flex items-center gap-1 text-stone-500 text-sm">Min order: ₹{restaurant.minOrder}</div>
          {/* Veg toggle */}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs font-semibold text-green-700">Veg Only</span>
            <button onClick={() => setVegOnly(!vegOnly)}
              className={`relative w-10 h-5 rounded-full transition-colors ${vegOnly ? 'bg-green-500' : 'bg-stone-300'}`}>
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${vegOnly ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Category sidebar */}
          <aside className="hidden md:block w-48 flex-shrink-0">
            <div className="sticky top-20 space-y-1">
              {Object.keys(filteredMenu).map(cat => (
                <button key={cat} onClick={() => {
                  setActiveCategory(cat);
                  document.getElementById(`cat-${cat}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                    activeCategory === cat ? 'bg-orange-50 text-orange-600' : 'text-stone-600 hover:bg-stone-50'
                  }`}>{cat}</button>
              ))}
            </div>
          </aside>

          {/* Menu items */}
          <div className="flex-1 space-y-8">
            {Object.keys(filteredMenu).length === 0 ? (
              <div className="text-center py-16"><p className="text-stone-400">No items match your filter</p></div>
            ) : Object.entries(filteredMenu).map(([category, items]) => (
              <div key={category} id={`cat-${category}`}>
                <h2 className="font-display text-xl font-bold text-stone-900 mb-4">{category}</h2>
                <div className="space-y-3">
                  {items.map(food => <FoodItemCard key={food._id} food={food} restaurant={restaurant} />)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Cart floating button */}
      {itemCount > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <Link to="/cart" className="bg-orange-500 text-white px-6 py-3.5 rounded-2xl shadow-xl shadow-orange-200 flex items-center gap-3 hover:bg-orange-600 transition-colors">
            <div className="w-6 h-6 bg-orange-400 rounded-full flex items-center justify-center text-xs font-bold">{itemCount}</div>
            <span className="font-semibold">View Cart</span>
            <span className="bg-orange-400 px-2 py-0.5 rounded-lg text-sm font-bold">₹{subtotal}</span>
            <ChevronRight size={18} />
          </Link>
        </div>
      )}
    </div>
  );
}
